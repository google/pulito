const { commonBuilder } = require('../webpack.common.js');
module.exports = commonBuilder(__dirname);
