const { commonBuilder } = require('pulito');
module.exports = commonBuilder(__dirname);
